# ZrAI - Professional AI Coding Assistant for Acode ⚡

A fast, responsive, and intelligent AI coding assistant plugin for **Android Acode Code Editor**. ZrAI integrates directly into your editor using the native `editorFile` API, opening an AI Chat tab alongside your active code files. Powered by Google's `gemini-3.5-flash` model.

---

## 🌟 Features
- **Native Editor Tab**: Seamlessly integrates into Acode's tab bar using the `editorFile` module.
- **Modern Responsive UI**: Clean, VS Code-inspired dark theme with automatic text-wrapping and scroll management.
- **Google Gemini 3.5 Flash**: Lightning-fast code generation, debugging, refactoring, and explanations.
- **Code Block Highlighting & Copy**: Pre-formatted syntax containers with instant 1-click clipboard copy.
- **Command Palette Integration**: Open the chat anytime via `Ctrl+Shift+P` > `open_custom_tab` or auto-launch upon startup.
- **Universal Developer Experience**: Clean, professional English interface designed for developers worldwide.

---

## 🚀 How to Use
1. Upon loading, the **⚡ ZrAI Chat** tab opens automatically in your tab bar. You can also run the `open_custom_tab` command anytime.
2. Click the key icon (🔑) in the chat header to enter your **Gemini API Key** from Google AI Studio.
3. Type your programming question, bug description, or code prompt into the message box and press **Enter**!
